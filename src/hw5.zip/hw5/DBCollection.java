package hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public class DBCollection {
	
	public static final String delimiter = "\n";

	public static void print(Object o) {
		System.out.println(o);
	}
	
	
	private DB database;
	private String name;
	private String path;
	private File file;
	private ArrayList<JsonObject> docPool;

	/**
	 * Constructs a collection for the given database
	 * with the given name. If that collection doesn't exist
	 * it will be created.
	 */
	public DBCollection(DB database, String name) {
		this.database = database;
		this.name = name;
		this.path = this.database.getPath() + "/" + name + ".json";
		this.file = new File(path);
		this.docPool = new ArrayList<JsonObject>();
		if(!this.file.exists()) {
			try {
				this.file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		ArrayList<String> docStrs = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();
		try {
			FileReader fr = new FileReader(this.path);
			BufferedReader br = new BufferedReader(fr);
//			String line = br.readLine();
			String line;
			while((line = br.readLine()) != null) {
				if(line.trim().length() != 0) {
					sb.append(line);
					System.out.println("append line:");
					System.out.println(line);
				}
				else {
					docStrs.add(new String(sb));
//					docStrs.add(sb.toString());
					sb.delete(0, sb.length());
				}
			}
			if(sb.length() > 0) {
				docStrs.add(new String(sb));
//				docStrs.add(sb.toString());
			}
				System.out.println("sb");
				System.out.println(sb.toString());
				br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(docStrs.size());
		
		for(String docStr: docStrs) {
			System.out.println(docStr);
//			System.out.println(Document.parse("{	\"key\":\"value\"}, {	\"embedded\": { \"key2\": \"value2\" }}, {	\"array\" : [\"one\", \"two\", \"three\"]}"));
//			System.out.println(Document.parse("{	\"key\":\"value\"}"));
			this.docPool.add(Document.parse(docStr));
			System.out.println(Document.parse(docStr));
//			System.out.println(docStr);
		}
//		System.out.println(Document.parse(docStr));
		
	}
	
	/**
	 * Returns a cursor for all of the documents in
	 * this collection.
	 */
	public DBCursor find() {
		DBCursor cursor = new DBCursor(this, null, null);
		return cursor;
	}
	
	/**
	 * Finds documents that match the given query parameters.
	 * 
	 * @param query relational select
	 * @return
	 */
	public DBCursor find(JsonObject query) {
		DBCursor cursor = new DBCursor(this, query, null);
		return cursor;
	}
	
	/**
	 * Finds documents that match the given query parameters.
	 * 
	 * @param query relational select
	 * @param projection relational project
	 * @return
	 */
	public DBCursor find(JsonObject query, JsonObject projection) {
		DBCursor cursor = new DBCursor(this, query, projection);
		return cursor;
	}
	
	private void write() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(this.file, false));
			for(JsonObject doc: this.docPool) {
				writer.write(gson.toJson(doc));
				writer.newLine();
				writer.newLine();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				print("failed to close!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				e.printStackTrace();
			}
		}
	}

	public void writee() {
//		for(JsonObject doc: docPool) {
//			this.write(doc);
//		}
		StringBuilder content = new StringBuilder();
		FileWriter fw = null;
		try { 
			fw = new FileWriter(this.file);
			int docPoolSize = this.docPool.size();
			for(int i=0; i<docPoolSize; i++) {
				content.append(this.docPool.get(i).toString());
				if(i != docPoolSize-1) {
					content.append(delimiter);
				}
			}
			fw.write(content.toString());
			fw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		finally {

			try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
	}
	public void writee(JsonObject doc) {
		StringBuilder content = new StringBuilder();
		try {
			FileWriter fw = new FileWriter(this.file);
			content.append(doc.toString());
			content.append(delimiter);
			fw.write(content.toString());
			fw.flush();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Inserts documents into the collection
	 * Must create and set a proper id before insertion
	 * When this method is completed, the documents
	 * should be permanently stored on disk.
	 * @param documents
	 */
	public void insert(JsonObject... documents) {
		for(JsonObject doc : documents) {
			if (!doc.has("_id")) {
				doc.addProperty("_id", UUID.randomUUID().toString());
			}
			this.docPool.add(doc);
			
//			this.writeJsonObject(doc, true);
			
		}
		this.write();
	}
	
	/**
	 * Locates one or more documents and replaces them
	 * with the update document.
	 * @param query relational select for documents to be updated
	 * @param update the document to be used for the update
	 * @param multi true if all matching documents should be updated
	 * 				false if only the first matching document should be updated
	 */
	public void update(JsonObject query, JsonObject update, boolean multi) {
		DBCursor matched = this.find(query);
		JsonObject doc = new JsonObject();
		
		
	}
	
	/**
	 * Removes one or more documents that match the given
	 * query parameters
	 * @param query relational select for documents to be removed
	 * @param multi true if all matching documents should be updated
	 * 				false if only the first matching document should be updated
	 */
	public void remove(JsonObject query, boolean multi) {
		DBCursor matched = this.find(query);
		while(matched.hasNext()) {
			JsonObject docToDel = matched.next();
			this.docPool.remove(docToDel);
			if(!multi) {
				break;
			}
		}
		this.write();
//		for(JsonObject doc:this.docPool) {
//			this.writeJsonObject(doc, true);
//		}
	}
	
	/**
	 * Returns the number of documents in this collection
	 */
	public long count() {
		return this.docPool.size();
	}
	
	
	
	
	

	
	public String getPath(){
		return this.path;
	}
	
	public ArrayList<JsonObject> getDocPool() {
		ArrayList<JsonObject> docPoolCopy = new ArrayList<JsonObject>();
		for(JsonObject doc: this.docPool) {
			docPoolCopy.add(doc);
		}
		return docPoolCopy;
	}
	
	public Iterator<JsonObject> getDocPoolIter() {
		return this.docPool.iterator();
	}
	
	public String getName() {
		return this.name;
	}
	
	/**
	 * Returns the ith document in the collection.
	 * Documents are separated by a line that contains only a single tab (\t)
	 * Use the parse function from the document class to create the document object
	 */
	public JsonObject getDocument(int i) {
		return i < this.docPool.size()? this.docPool.get(i) : null;
	}
	
	/**
	 * Drops this collection, removing all of the documents it contains from the DB
	 */
	public void drop() {
		print("!!!drop");
		if(this.file.exists()) {
			print("exists:"+this.file.getPath());
			print(this.file.getAbsolutePath());

			InputStream inputStream;
			try {
				inputStream = new FileInputStream(this.file);
				
				if (inputStream != null) {
		            inputStream.close();
		        }
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			boolean success = this.file.delete();
			print(success);
			print(this.file.exists());
			if(!success) {
				print("not suceess");
				File delFile = new File(this.getPath());
				boolean success2 = delFile.delete();
				print(success2);
			}
		}
	}
	
}
//package hw5;
//
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Set;
//import java.util.UUID;
//
//import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
//import com.google.gson.JsonObject;
//import com.google.gson.JsonPrimitive;
//
//public class DBCollection {
//
//	private final String JSON_SUFFIX = ".json";
//	private final String ID_FIELD_NAME = "_id";
//
//	private DB db;
//	private String name; // collection name
//	private String collectionPath;
//	private File collectionFile;
//	private List<JsonObject> documents; // all the modification must first happen in memory
//
//	/**
//	 * Constructs a collection for the given database with the given name. If that
//	 * collection doesn't exist it will be created.
//	 */
//	public DBCollection(DB database, String name) {
//		this.db = database;
//		this.name = name;
//		this.collectionPath = this.db.getPath() + "/" + this.name + JSON_SUFFIX;
//		this.collectionFile = new File(collectionPath);
//		this.documents = new ArrayList<JsonObject>();
//
//		preProcess();
//	}
//
//	/**
//	 * Returns a cursor for all of the documents in this collection.
//	 */
//	public DBCursor find() {
//		DBCursor cusor = new DBCursor(this, null, null);
//		return cusor;
//	}
//
//	/**
//	 * Finds documents that match the given query parameters.
//	 * 
//	 * @param query relational select
//	 * @return
//	 */
//	public DBCursor find(JsonObject query) {
//		DBCursor cusor = new DBCursor(this, query, null);
//		return cusor;
//	}
//
//	/**
//	 * Finds documents that match the given query parameters.
//	 * 
//	 * @param query      relational select
//	 * @param projection relational project
//	 * @return
//	 */
//	public DBCursor find(JsonObject query, JsonObject projection) {
//		DBCursor cusor = new DBCursor(this, query, projection);
//		return cusor;
//	}
//
//	/**
//	 * Inserts documents into the collection Must create and set a proper id before
//	 * insertion When this method is completed, the documents should be permanently
//	 * stored on disk.
//	 * 
//	 * @param documents
//	 */
//	public void insert(JsonObject... documents) {
//		for (JsonObject object : documents) {
//			if (!object.has("_id")) {
//				UUID uuid = UUID.randomUUID();
//				object.addProperty(this.ID_FIELD_NAME, uuid.toString());
//			}
//			this.documents.add(object);
//			writeJsonObject(object, true);
//		}
//	}
//
//	/**
//	 * Locates one or more documents and replaces them with the update document.
//	 * 
//	 * @param query  relational select for documents to be updated
//	 * @param update the document to be used for the update
//	 * @param multi  true if all matching documents should be updated false if only
//	 *               the first matching document should be updated
//	 */
//	public void update(JsonObject query, JsonObject update, boolean multi) {
//		List<Integer> indexList = new ArrayList<>();
//		List<JsonObject> objList = new ArrayList<>();
//
//		for (int i = 0; i < this.documents.size(); i++) {
//			JsonObject object = this.documents.get(i);
//			if (matchQuery(object, query)) {
//				indexList.add(i);
//				objList.add(updateJson(object, update));
//			}
//		}
//
//		for (int i = 0; i < indexList.size(); i++) {
//			this.documents.set(indexList.get(i), objList.get(i));
//			if (!multi)
//				break;
//		}
//
//		this.clearCollection();
//		for (JsonObject obj : this.documents) {
//			this.writeJsonObject(obj, true);
//		}
//	}
//
//	/**
//	 * Removes one or more documents that match the given query parameters
//	 * 
//	 * @param query relational select for documents to be removed
//	 * @param multi true if all matching documents should be updated false if only
//	 *              the first matching document should be updated
//	 */
//	public void remove(JsonObject query, boolean multi) {
//		Iterator<JsonObject> iterator = this.documents.iterator();
//		while (iterator.hasNext()) {
//			JsonObject object = iterator.next();
//			if (matchQuery(object, query)) {
//				iterator.remove();
//				if (!multi)
//					break;
//			}
//		}
//
//		this.clearCollection();
//		for (JsonObject obj : this.documents) {
//			this.writeJsonObject(obj, true);
//		}
//	}
//
//	/**
//	 * Returns the number of documents in this collection
//	 */
//	public long count() {
//		return this.documents.size();
//	}
//
//	public String getName() {
//		return this.name;
//	}
//
//	public String getCollectionPath() {
//		return this.collectionPath;
//	}
//
//	/**
//	 * Returns the ith document in the collection. Documents are separated by a line
//	 * that contains only a single tab (\t) Use the parse function from the document
//	 * class to create the document object
//	 */
//	public JsonObject getDocument(int i) {
//		if (i < this.documents.size()) {
//			return this.documents.get(i);
//		}
//		return null;
//	}
//
//	/**
//	 * Drops this collection, removing all of the documents it contains from the DB
//	 */
//	public void drop() {
//		if (this.collectionFile.exists()) {
//			this.collectionFile.delete();
//		}
//	}
//
//	
//	public List<JsonObject> deepCopy(){
//		List<JsonObject> list = new ArrayList<>();
//		for(JsonObject object: this.documents) {
//			list.add(object.deepCopy());
//		}
//		
//		return list;
//	}
//	
//	private void preProcess() {
//		if (!this.collectionFile.exists()) {
//			try {
//				this.collectionFile.createNewFile();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//
//		List<String> temp = this.readAllJsonObjects();
//	System.out.println("temp");
//	System.out.println(temp);
//		for (String s : temp) {
//			System.out.println(Document.parse(s));
//			this.documents.add(Document.parse(s));
//		}
//
//	}
//
//	private void clearCollection() {
//		PrintWriter writer;
//		try {
//			writer = new PrintWriter(this.collectionPath);
//			writer.print("");
//			writer.close();
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	private void writeJsonObject(JsonObject object, boolean append) {
//		Gson gson = new GsonBuilder().setPrettyPrinting().create();
//		BufferedWriter writer = null;
//		try {
//			writer = new BufferedWriter(new FileWriter(this.collectionFile, append));
//			writer.write(gson.toJson(object));
//			writer.newLine();
//			writer.newLine();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} finally {
//			try {
//				writer.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	}
//
//	private List<String> readAllJsonObjects() {
//		List<String> list = new ArrayList<>();
//		StringBuilder builder = new StringBuilder();
//		try {
//			@SuppressWarnings("resource")
//			BufferedReader reader = new BufferedReader(new FileReader(this.collectionPath));
//			String line = reader.readLine();
//
//			while (line != null) {
//				if (line.trim().length() == 0) {
//					list.add(new String(builder));
//					builder = new StringBuilder();
//				} else {
//					builder.append(line);
//				}
//				line = reader.readLine();
//			}
//
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//
//		if (builder.length() != 0)
//			list.add(new String(builder));
//		System.out.println(list.size());
//		return list;
//	}
//
//	private boolean matchQuery(JsonObject object, JsonObject query) {
//		Set<String> keySet = query.keySet();
//		Iterator<String> iter = keySet.iterator();
//		while (iter.hasNext()) {
//			JsonObject tempObject = object;
//
//			String queryString = iter.next();
//			String[] splited = queryString.split("\\.");
//			for (int i = 0; i < splited.length - 1; i++) {
//				if (tempObject.has(splited[i])) {
//					tempObject = tempObject.getAsJsonObject(splited[i]);
//				} else {
//					return false;
//				}
//			}
//			JsonPrimitive primitive = tempObject.getAsJsonPrimitive(splited[splited.length - 1]);
//			if (!query.getAsJsonPrimitive(queryString).getAsString().equals(primitive.getAsString())) {
//				return false;
//			}
//		}
//		return true;
//	}
//
//	private JsonObject updateJson(JsonObject object, JsonObject update) {
//		JsonObject newObject = object.deepCopy();
//
//		Set<String> keySet = update.keySet();
//		Iterator<String> iter = keySet.iterator();
//		while (iter.hasNext()) {
//			JsonObject tempObject = newObject;
//
//			String queryString = iter.next();
//			String[] splited = queryString.split("\\.");
//			for (int i = 0; i < splited.length - 1; i++) {
//				tempObject = tempObject.getAsJsonObject(splited[i]);
//			}
//
//			tempObject.remove(splited[splited.length - 1]);
//			tempObject.add(splited[splited.length - 1], update.get(queryString));
//		}
//
//		return newObject;
//	}
//}